console.log('script.js loaded');
console.log(document.getElementById('header').innerHTML);

// You can write JavaScript below this comment and it will load when you open index.html

